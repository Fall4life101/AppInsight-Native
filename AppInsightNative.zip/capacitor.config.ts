import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.appinsight.app',
  appName: 'AppInsight',
  webDir: 'dist/public',
  bundledWebRuntime: false
};

export default config;
