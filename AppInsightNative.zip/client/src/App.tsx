import React from 'react';

function App() {
  return <h1>Hello from AppInsight Native!</h1>;
}

export default App;
